
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'deserie',
  applicationName: 'serverless-restaurant',
  appUid: 'kWpg1yYh64h9JJpc3k',
  orgUid: '0ldCPjfrZ4kYfy3lvl',
  deploymentUid: '97010e88-95d7-44b3-8d18-38a6757874e4',
  serviceName: 'serverless-restaurant',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.1.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-restaurant-dev-get-index', timeout: 6 };

try {
  const userHandler = require('./functions/get-index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}