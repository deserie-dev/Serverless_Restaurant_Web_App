
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'deserie',
  applicationName: 'serverless-restaurant',
  appUid: 'kWpg1yYh64h9JJpc3k',
  orgUid: '0ldCPjfrZ4kYfy3lvl',
  deploymentUid: '8813d271-151b-4790-954b-3ffb6bc18af0',
  serviceName: 'serverless-restaurant',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.1.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-restaurant-dev-get-index', timeout: 6 };

try {
  const userHandler = require('./functions/get-index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}